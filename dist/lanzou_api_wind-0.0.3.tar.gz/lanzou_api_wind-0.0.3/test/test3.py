import asyncio

async def _async_all_possible_urls():
    for i in range(10):
        await asyncio.sleep(0.1)  # 使用 await 等待 asyncio.sleep 完成
        yield i

async def main():
    async for i in _async_all_possible_urls():
        print(i)

if __name__ == "__main__":  # 修正为 __name__
    asyncio.run(main())